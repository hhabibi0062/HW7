#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define MAX 15

int equal_words(char *word1 , char *word2) ;

struct word
{
    char lan1[MAX] ;
    char lan2[MAX] ;
};

int main()
{
    int n ;
    printf("enter number of words:\n") ;
    scanf("%d",&n) ;

    struct word array[n] ;

    for(int i = 0 ; i < n ; i++)
    {
        printf("enter word%d in both languages:\n",i + 1) ;
        scanf("%s %s",array[i].lan1,array[i].lan2) ;
    }


    char string0[100] ;
    char string[100] ;
    int counter = 1 ;
    int k = 0 ;
    getchar();
    printf("enter string in first language:\n");
    fgets(string0 , 100 , stdin) ;

    if(islower(array[0].lan1[0]))
        for(int i = 0 ; string0[i] != '\0' ; i++)
            string[i] = tolower(string0[i]) ;
    else
        for(int i = 0 ; string0[i] != '\0' ; i++)
            string[i] = toupper(string0[i]) ;


    for(int i = 0 ; string[i] != '\0' ; i++)
    {
        if(isspace(string[i]))
            counter++ ;
    }

    char words[counter][MAX] ;
    int word_count = 0 ;
    for(int j = 0 ; string[j] != '\0' ; j++)
    {
        if(!isspace(string[j]))
            words[word_count][k++] = string[j] ;
        else if(isspace(string[j]))
        {
            words[word_count][k] = '\0' ;
            word_count++ ;
            k = 0 ;
        }
    }

    words[word_count][k] = '\0' ;

    for(int i = 0 ; i < counter ; i++)
    {
        for(int j = 0 ; j < n ; j++)
        {
            if(equal_words(words[i] , array[j].lan1))
            {
                if(strlen(array[j].lan2) < strlen(array[j].lan1))
                    printf("%s ",array[j].lan2) ;
                else
                    printf("%s ",array[j].lan1) ;
            }
        }
    }
    return 0 ;
}


int equal_words(char *word1 , char *word2) 
{
    if(strlen(word1) != strlen(word2))
        return 0 ;
    else
    {
        for(int i = 0 ; i < strlen(word1) ; i++)
        {
            if(word1[i] != word2[i])
                return 0 ;
        }
    }

    return 1 ;
}